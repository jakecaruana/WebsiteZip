function moreaboutme() {
   let text = document.getElementById("moreaboutme");
   if (text.style.display === "none") {
       text.style.display = "block";
   } else {
       text.style.display = "none";
   }
}

function viewmore() {
    let text = document.getElementById("viewmore");
    if (text.style.display === "none") {
        text.style.display = "block";
    } else {
        text.style.display = "none";
    }
 }
 
 function supriseme() {
    let text = document.getElementById("supriseme");
    if (text.style.display === "none") {
        text.style.display = "block";
    } else {
        text.style.display = "none";
    }
 }

 